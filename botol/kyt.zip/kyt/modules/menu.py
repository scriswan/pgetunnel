from kyt import *
import subprocess
import json
import os

# flag custom menu
custom_menu = True   # ubah ke False kalau tidak mau tampil menu tambahan

# load daftar server dari file
with open("servers.json") as f:
    servers = json.load(f)

# fungsi eksekusi perintah di server lain via SSH / password
def remote_exec(server, cmd):
    try:
        if "password" in server and server["password"]:
            # login pakai password
            return subprocess.check_output(
                f'sshpass -p "{server["password"]}" ssh -o StrictHostKeyChecking=no {server["user"]}@{server["host"]} "{cmd}"',
                shell=True
            ).decode().strip()
        else:
            # login pakai ssh key
            return subprocess.check_output(
                f'ssh -o StrictHostKeyChecking=no {server["user"]}@{server["host"]} "{cmd}"',
                shell=True
            ).decode().strip()
    except Exception as e:
        return f"Error: {e}"

# --- Handler utama MENU ---
@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline("🌐 SSH-WS", "ssh"), Button.inline("🔒 VMESS", "vmess")],
        [Button.inline("🌍 VLESS", "vless"), Button.inline("🚫 TROJAN", "trojan")],
        [Button.inline("⚙️ SETTING", "setting"), Button.inline("🖥 VPS INFO", "info")]
    ]

    # ✅ tambahkan tombol MULTI SERVER hanya kalau custom_menu aktif
    if custom_menu:
        inline.append([Button.inline("🌐 MULTI SERVER", "multiserver")])

    inline.append([Button.inline("🔙 BACK MENU", "start")])
    
    sender = await event.get_sender()
    val = valid(str(sender.id))
    
    if val == "false":
        try:
            await event.answer("", alert=True)
        except:
            await event.reply("")
    elif val == "true":
        # --- Info VPS utama ---
        ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode().strip()
        location = subprocess.check_output(f"curl -s http://ipinfo.io/{ipsaya}/json", shell=True).decode()
        location_info = json.loads(location)

        city = location_info.get('city', 'Tidak Diketahui')
        country = location_info.get('country', 'Tidak Diketahui')
        isp = location_info.get('org', 'Tidak Diketahui').split(' ', 1)[-1]

        ram = subprocess.check_output("free -h | grep Mem | awk '{print $2}'", shell=True).decode().strip()
        uptime = subprocess.check_output("uptime -p", shell=True).decode().strip()
        vps_time = subprocess.check_output("date '+%d-%m-%Y %H:%M:%S'", shell=True).decode().strip()

        msg = f"""
╔════════════════════╗
                🤖 BOT PANEL
╚════════════════════╝
📡 **SERVER INFO (UTAMA)**
╔════════════════════╗
║ Location: `{city}, {country}`
║ ISP: `{isp}`
║ IP VPS: `{ipsaya}`
║ Domain: `{DOMAIN}`
║ RAM: `{ram}`
║ Uptime: `{uptime}`
║ Waktu: `{vps_time}`
╚════════════════════╝

🆕 Untuk lihat server lain buka menu MULTI SERVER
║👨‍💻 **Owner**   : @JesVpnt
║🔧 **Version** : `3.2`
╚════════════════════╝
"""

        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)


# --- Handler MULTI SERVER ---
if custom_menu:
    @bot.on(events.CallbackQuery(data=b'multiserver'))
    async def multi_server_menu(event):
        buttons = []
        for s in servers:
            buttons.append([Button.inline(f"🌐 {s['name']}", f"server_{s['name']}")])
        buttons.append([Button.inline("⬅️ Kembali", b"menu")])

        msg = "🌐 **MENU MULTI SERVER**\n\nPilih server yang ingin dicek:"
        await event.edit(msg, buttons=buttons)

    # generate handler dinamis untuk setiap server
    for s in servers:
        async def handler(event, server=s):
            # ambil data akun dari server remote
            ssh = remote_exec(server, 'cat /etc/passwd | grep "home" | grep "false" | wc -l')
            vms = remote_exec(server, 'cat /etc/vmess/.vmess.db | grep "###" | wc -l')
            vls = remote_exec(server, 'cat /etc/vless/.vless.db | grep "###" | wc -l')
            trj = remote_exec(server, 'cat /etc/trojan/.trojan.db | grep "###" | wc -l')
            ss  = remote_exec(server, 'cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l')

            ipsaya = remote_exec(server, "curl -s ipv4.icanhazip.com")
            location = remote_exec(server, f"curl -s http://ipinfo.io/{ipsaya}/json")

            try:
                location_info = json.loads(location)
                city = location_info.get('city', 'Tidak Diketahui')
                country = location_info.get('country', 'Tidak Diketahui')
                isp = location_info.get('org', 'Tidak Diketahui').split(' ', 1)[-1]
            except:
                city, country, isp = "?", "?", "?"

            ram = remote_exec(server, "free -h | grep Mem | awk '{print $2}'")
            uptime = remote_exec(server, "uptime -p")
            vps_time = remote_exec(server, "date '+%d-%m-%Y %H:%M:%S'")

            msg = f"""
╔════════════════════╗
        🌐 {server['name']}
╚════════════════════╝
📡 **SERVER INFO**
╔════════════════════╗
║ Location: `{city}, {country}`
║ ISP: `{isp}`
║ IP VPS: `{ipsaya}`
║ RAM: `{ram}`
║ Uptime: `{uptime}`
║ Waktu: `{vps_time}`
╚════════════════════╝
⚡ **AKUN PREMIUM**
╔════════════════════╗
║ SSH: `{ssh}`
║ VMESS: `{vms}`
║ VLESS: `{vls}`
║ TROJAN: `{trj}`
║ SS: `{ss}`
╚════════════════════╝
"""
            buttons = [[Button.inline("⬅️ Kembali", b"multiserver")]]
            await event.edit(msg, buttons=buttons)

        bot.add_event_handler(handler, events.CallbackQuery(data=f'server_{s["name"]}'.encode()))