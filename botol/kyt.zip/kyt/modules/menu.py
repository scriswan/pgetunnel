from kyt import *
import subprocess
import json

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline("🌐 SSH-WS", "ssh"), Button.inline("🔒 VMESS", "vmess")],
        [Button.inline("🌍 VLESS", "vless"), Button.inline("🚫 TROJAN", "trojan")],
        [Button.inline("⚙️ SETTING", "setting"), Button.inline("🖥 VPS INFO", "info")],
        [Button.inline("🔙 BACK MENU", "start")]
    ]
    
    sender = await event.get_sender()
    val = valid(str(sender.id))
    
    if val == "false":
        try:
            await event.answer("", alert=True)
        except:
            await event.reply("")
    elif val == "true":
        # --- Hitung jumlah akun aktif ---
        ssh = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode().strip()
        vms = subprocess.check_output('cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode().strip()
        vls = subprocess.check_output('cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode().strip()
        trj = subprocess.check_output('cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode().strip()
        shadowsocks = subprocess.check_output('cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l', shell=True).decode().strip()

        # --- Info VPS ---
        ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode().strip()
        location = subprocess.check_output(f"curl -s http://ipinfo.io/{ipsaya}/json", shell=True).decode()
        location_info = json.loads(location)

        city = location_info.get('city', 'Tidak Diketahui')
        country = location_info.get('country', 'Tidak Diketahui')
        isp = location_info.get('org', 'Tidak Diketahui').split(' ', 1)[-1]

        ram = subprocess.check_output("free -h | grep Mem | awk '{print $2}'", shell=True).decode().strip()
        uptime = subprocess.check_output("uptime -p", shell=True).decode().strip()
        vps_time = subprocess.check_output("date '+%d-%m-%Y %H:%M:%S'", shell=True).decode().strip()

        # --- Tampilan Pesan ---
        msg = f"""
╔════════════════════╗
                🤖 BOT PANEL
╚════════════════════╝
📡 **SERVER INFO**
╔════════════════════╗
║ Location: `{city}, {country}`
║ ISP: `{isp}`
║ IP VPS: `{ipsaya}`
║ Domain: `{DOMAIN}`
║ RAM: `{ram}`
║ Uptime: `{uptime}`
║ Waktu: `{vps_time}`
╚════════════════════╝
⚡ **AKUN PREMIUM**
╔════════════════════╗
║ SSH: `{ssh}`
║ VMESS: `{vms}`
║ VLESS: `{vls}`
║ TROJAN: `{trj}`
║ SS: `{shadowsocks}`
╚════════════════════╝
║👨‍💻 **Owner**   : @JesVpnt
║🔧 **Version** : `3.2`
╚════════════════════╝
"""

        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)