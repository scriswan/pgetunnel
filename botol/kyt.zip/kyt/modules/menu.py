from kyt import *
import subprocess, json

# -------------------------------
# Fungsi Register Menu (fixed regex)
# -------------------------------
def register_menu(bot_instance, commands=("menu", "start")):
    # bikin regex: tangkep .cmd /cmd di awal pesan
    pattern = r"^(?:{})".format("|".join([f"\.{cmd}|/{cmd}" for cmd in commands]))

    @bot_instance.on(events.NewMessage(pattern=pattern))
    @bot_instance.on(events.CallbackQuery(data=b'menu'))
    async def menu(event):
        inline = [
            [Button.inline("🌐 SSH-WS", "ssh"), Button.inline("🔒 VMESS", "vmess")],
            [Button.inline("🌍 VLESS", "vless"), Button.inline("🚫 TROJAN", "trojan")],
            [Button.inline("⚙️ SETTING", "setting"), Button.inline("🖥 VPS INFO", "info")],
            [Button.inline("🔙 BACK MENU", "start")]
        ]

        sender = await event.get_sender()
        val = valid(str(sender.id))
        if val == "false":
            try: 
                await event.answer("", alert=True)
            except:
                await event.reply("")
            return

        # --- Hitung jumlah akun ---
        ssh = sh("cat /etc/passwd | awk -F: '{print $6}' | grep -E '^/home' | wc -l", "0")
        vms = sh("grep -c '###' /etc/vmess/.vmess.db 2>/dev/null || echo 0", "0")
        vls = sh("grep -c '###' /etc/vless/.vless.db 2>/dev/null || echo 0", "0")
        trj = sh("grep -c '###' /etc/trojan/.trojan.db 2>/dev/null || echo 0", "0")
        shadowsocks = sh("grep -c '###' /etc/shadowsocks/.shadowsocks.db 2>/dev/null || echo 0", "0")

        ipsaya = sh("curl -s ipv4.icanhazip.com", "0.0.0.0")
        location = sh(f"curl -s http://ipinfo.io/{ipsaya}/json", "{}")
        try:
            location_info = json.loads(location)
        except:
            location_info = {}

        city = location_info.get('city', 'Tidak Diketahui')
        country = location_info.get('country', 'Tidak Diketahui')
        isp_val = location_info.get('org', 'Tidak Diketahui')
        isp = isp_val.split(' ', 1)[-1] if isinstance(isp_val, str) and ' ' in isp_val else isp_val

        ram = sh("free -h | awk '/Mem:/ {print $2}'", "Unknown")
        uptime = sh("uptime -p", "Unknown")
        vps_time = sh("date '+%d-%m-%Y %H:%M:%S'", "Unknown")

        msg = f"""
╔════════════════════╗
                🤖 BOT PANEL
╚════════════════════╝
📡 **SERVER INFO**
╔════════════════════╗
║ Location: `{city}, {country}`
║ ISP: `{isp}`
║ IP VPS: `{ipsaya}`
║ Domain: `{DOMAIN}`
║ RAM: `{ram}`
║ Uptime: `{uptime}`
║ Waktu: `{vps_time}`
╚════════════════════╝
⚡ **AKUN PREMIUM**
╔════════════════════╗
║ SSH: `{ssh}`
║ VMESS: `{vms}`
║ VLESS: `{vls}`
║ TROJAN: `{trj}`
║ SS: `{shadowsocks}`
╚════════════════════╝
║👨‍💻 **Owner**   : @JesVpnt
║🔧 **Version** : `3.2`
╚════════════════════╝
"""
        try:
            await event.edit(msg, buttons=inline)
        except:
            await event.reply(msg, buttons=inline)