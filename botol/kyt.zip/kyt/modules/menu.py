from kyt import *
import subprocess, json

# -------------------------------
# Baca Custom Command
# -------------------------------
try:
    with open("/etc/bot_command.conf", "r") as f:
        CUSTOM_CMDS = f.read().strip().split()
        if not CUSTOM_CMDS:
            CUSTOM_CMDS = ["menu"]  # default
except FileNotFoundError:
    CUSTOM_CMDS = ["menu"]  # default

# -------------------------------
# Helper: safe shell getoutput
# -------------------------------
def sh(cmd, fallback="0"):
    try:
        out = subprocess.getoutput(cmd).strip()
        if out == "":
            return fallback
        return out
    except Exception:
        return fallback

# -------------------------------
# Fungsi Register Menu
# -------------------------------
def register_menu(bot_instance, commands=("menu", "start")):
    # build regex pattern: support .cmd and /cmd for each command
    pattern = r"(?:{})$".format("|".join([f"\.{cmd}|/{cmd}" for cmd in commands]))

    @bot_instance.on(events.NewMessage(pattern=pattern))
    @bot_instance.on(events.CallbackQuery(data=b'menu'))
    async def menu(event):
        inline = [
            [Button.inline("🌐 SSH-WS", "ssh"), Button.inline("🔒 VMESS", "vmess")],
            [Button.inline("🌍 VLESS", "vless"), Button.inline("🚫 TROJAN", "trojan")],
            [Button.inline("⚙️ SETTING", "setting"), Button.inline("🖥 VPS INFO", "info")],
            [Button.inline("🔙 BACK MENU", "start")]
        ]

        sender = await event.get_sender()
        val = valid(str(sender.id))
        if val == "false":
            try: 
                await event.answer("", alert=True)
            except:
                await event.reply("")
            return

        # --- Hitung jumlah akun aktif ---
        # SSH: menghitung user dengan home dan shell false (sesuaikan kondisi grep jika berbeda)
        ssh = sh("cat /etc/passwd | awk -F: '{print $6}' | grep -E '^/home' | wc -l", "0")

        # VMess, VLESS, Trojan, Shadowsocks: hitung baris yang menandakan akun (misal '###')
        vms = sh("if [ -f /etc/vmess/.vmess.db ]; then grep -c '###' /etc/vmess/.vmess.db || true; else echo 0; fi", "0")
        vls = sh("if [ -f /etc/vless/.vless.db ]; then grep -c '###' /etc/vless/.vless.db || true; else echo 0; fi", "0")
        trj = sh("if [ -f /etc/trojan/.trojan.db ]; then grep -c '###' /etc/trojan/.trojan.db || true; else echo 0; fi", "0")
        shadowsocks = sh("if [ -f /etc/shadowsocks/.shadowsocks.db ]; then grep -c '###' /etc/shadowsocks/.shadowsocks.db || true; else echo 0; fi", "0")

        # --- Info VPS ---
        ipsaya = sh("curl -s ipv4.icanhazip.com", "0.0.0.0")
        location = sh(f"curl -s http://ipinfo.io/{ipsaya}/json", "{}")
        try:
            location_info = json.loads(location)
        except:
            location_info = {}

        city = location_info.get('city', 'Tidak Diketahui')
        country = location_info.get('country', 'Tidak Diketahui')
        isp_val = location_info.get('org', 'Tidak Diketahui')
        isp = isp_val.split(' ', 1)[-1] if isinstance(isp_val, str) and ' ' in isp_val else isp_val

        ram = sh("free -h | awk '/Mem:/ {print $2}'", "Unknown")
        uptime = sh("uptime -p", "Unknown")
        vps_time = sh("date '+%d-%m-%Y %H:%M:%S'", "Unknown")

        # --- Tampilan Pesan ---
        msg = f"""
╔════════════════════╗
                🤖 BOT PANEL
╚════════════════════╝
📡 **SERVER INFO**
╔════════════════════╗
║ Location: `{city}, {country}`
║ ISP: `{isp}`
║ IP VPS: `{ipsaya}`
║ Domain: `{DOMAIN}`
║ RAM: `{ram}`
║ Uptime: `{uptime}`
║ Waktu: `{vps_time}`
╚════════════════════╝
⚡ **AKUN PREMIUM**
╔════════════════════╗
║ SSH: `{ssh}`
║ VMESS: `{vms}`
║ VLESS: `{vls}`
║ TROJAN: `{trj}`
║ SS: `{shadowsocks}`
╚════════════════════╝
║👨‍💻 **Owner**   : @JesVpnt
║🔧 **Version** : `3.2`
╚════════════════════╝
"""

        try:
            # jika event adalah callback query (ada pesan sebelumnya), edit; kalau gagal, kirim reply
            try:
                await event.edit(msg, buttons=inline)
            except Exception:
                await event.reply(msg, buttons=inline)
        except Exception:
            # fallback terakhir: kirim pesan tanpa tombol
            try:
                await event.reply(msg)
            except:
                pass

# -------------------------------
# Daftarkan ke Bot
# -------------------------------
register_menu(bot, commands=tuple(CUSTOM_CMDS))